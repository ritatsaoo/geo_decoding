import csv
import numpy as np
import pandas as pd
from datetime import datetime
from Lily.ctao2.ctao2_database_alias import manidb, alias, tickwatch
from multiprocessing import Pool

   
#%%
def make_dict(arg):
    datalist =[]
    file = open(arg, mode='r',encoding="utf-8")
    lines = file.readlines()

    #for row in lines:
    #    dictionary_D = {}
    #    dictionary_D['HSN_CD']            = row[0]
    #    dictionary_D['HOU_LOSN']          = row[1:12]
    #    dictionary_D['LOCAT_ADDR']        = row[325:502]

    #    dictionary_D['LOCAL_CD']          = row[90:101]
    #    dictionary_D['OWNER_TP']          = row[101:112]
    #    dictionary_D['HOU_BL_TP']         = row[112:123]
    #    dictionary_D['ESTAB_LOSN_DATE']   = row[123:124]
    #    dictionary_D['SPC_ADDR_MK']       = row[35:38] 
    #    dictionary_D['USE_LIC_NO']        = row[167:172]
        
    #    datalist.append(dictionary_D)

    for row in lines:
        dictionary_E = {}
        dictionary_E['HSN_CD']              = row[0]
        dictionary_E['HOU_LOSN']            = row[1:13]
        dictionary_E['HOU_FLOOR_NO']        = row[13:15]
        dictionary_E['CARD_SEQ1']           = row[15]
        dictionary_E['CARD_SEQ2']           = row[16]
        dictionary_E['HOU_BUILD_TP']        = row[17]
        dictionary_E['PUB_FAC_CD']          = row[18]
        dictionary_E['STRUC_TP']            = row[19] 
        dictionary_E['HOU_USE_TP']          = row[20]
        dictionary_E['HOU_USE_DTL_TP']      = row[21:23]
        dictionary_E['TOT_FLOOR']           = row[23:26] 
        dictionary_E['HOU_STD_PRC']         = row[26:34]
        dictionary_E['HOU_STD_PRC_SEQ_NO']  = row[34]
        dictionary_E['HOU_FLOOR_HIGH']      = row[35:38] 
        dictionary_E['HOU_APL_PRC']         = row[38:46]
        dictionary_E['HOU_USE_CD']          = row[46]
        dictionary_E['AIR_C_ELEV_VAL']      = row[47:57]
        dictionary_E['HOU_DEPR_RATE']       = row[57:62] 
        dictionary_E['DEPR_RATE_SEQ_NO']    = row[62]
        dictionary_E['HOU_DEPR_YEAR']       = row[63:65] 
        dictionary_E['HOU_LND_SEC_RATE']    = row[65:68]
        dictionary_E['BUSI_AREA']           = row[68:79]
        dictionary_E['BUSI_HALF_AREA']      = row[79:90]
        dictionary_E['RESD_AREA']           = row[90:101] 
        dictionary_E['RESD_HALF_AREA']      = row[101:112]
        dictionary_E['NRB_AREA']            = row[112:123]
        dictionary_E['NRB_HALF_AREA']       = row[123:134]
        dictionary_E['HOU_SLVY_YM']         = row[167:172] 
        dictionary_E['PR_VAL_CNVR']         = row[172:175]
        dictionary_E['HOU_APL_PR_VAL']      = row[286:296]
        dictionary_E['PORCH_AREA']          = row[508:519]
        dictionary_E['HOU_TOT_AREA']        = row[570:581] 
        dictionary_E['HOU_TOT_PR_VAL']      = row[581:591]

        datalist.append(dictionary_E)
        
    return datalist

if __name__ == '__console__' or __name__ == '__main__':
    cputime = tickwatch()
    mpool = Pool(8)
    output = make_dict('G:/NCREE_GIS/tgbs_data_cleaning_2020/housetax/keelung/HOUF43E.txt')
    mpool.close()
    cputime.tick()

    df = pd.DataFrame(output)
    writer = pd.ExcelWriter('g:/ncree_gis/tgbs_data_cleaning_2020/housetax/keelung/HOUF43E_export.xlsx', engine='xlsxwriter')
    df.to_excel(writer, sheet_name ='data0', index = False)
    writer.save()
    cputime.tick('write down dataframe')


    




