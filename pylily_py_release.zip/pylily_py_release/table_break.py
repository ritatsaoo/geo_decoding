import csv
import numpy as np
import pandas as pd

#%% text conversion
CT2_HTAB_SECT_NUM = str.maketrans (
    {
    '0':'○',
    'ㄧ':'一',
    '1':'一', 
    '2':'二',
    '3':'三',
    '4':'四',
    '5':'五',
    '6':'六',
    '7':'七',
    '8':'八',
    '9':'九',
#０-９ 65296-65305
    65296:'○',
    65297:'一', 
    65298:'二', 
    65299:'三', 
    65300:'四', 
    65301:'五', 
    65302:'六', 
    65303:'七', 
    65304:'八',
    65305:'九'
    })

CT2_HTAB_NUM = str.maketrans(
   {
    '○':'0',
    'ㄧ':'1',
    '一':'1', 
    '二':'2',
    '三':'3',
    '四':'4',
    '五':'5',
    '六':'6',
    '七':'7',
    '八':'8',
    '九':'9',
    '十':'10',
#０-９ 65296-65305
    65296:'0', 
    65297:'1', 
    65298:'2', 
    65299:'3', 
    65300:'4', 
    65301:'5', 
    65302:'6', 
    65303:'7', 
    65304:'8',
    65305:'9'
    })
to_comment = str.maketrans(
   {
    '臨':'',
    '近':'',
    '_'  :',',
    '號' :',,'
    })
to_comment2 = str.maketrans(
   {
    '臨':'',
    '近':'',
    '_'  :',',
    '-'  :',',
    '號' :','
    })
'''
to_towncode = str.maketrans(
   {
    '6301':'臺北,松山',
    '6302':'臺北,信義',
    '6303':'臺北,大安',
    '6304':'臺北,中山',
    '6305':'臺北,中正',
    '6306':'臺北,大同',
    '6307':'臺北,萬華',
    '6308':'臺北,文山',
    '6309':'臺北,南港',
    '6310':'臺北,內湖',
    '6311':'臺北,士林',
    '6312':'臺北,北投'
    })
'''
#%% read csv




H2=[]; H3=[];
with open('G:/NCREE_GIS/2020地址定位資料/newtp_address.csv', newline='') as csvfile:
    next(csvfile) # skip headline
    rows = csv.reader(csvfile)
    for row in rows:
        #change string type from number to traditional chinese
        address_split      = row[1].split(',',2)
        address_in_chinese = address_split[1].translate(CT2_HTAB_SECT_NUM)

        H2.append(address_in_chinese)
        #H2.append(address_split[3].translate(to_comment))
        if '-' in address_split[2]:
            H3.append(address_split[2].translate(to_comment2))
        else:
            H3.append(address_split[2].translate(to_comment))

print ('step 1')
#%%
'''
import sqlite3
# connect to database
connect = sqlite3.connect('D:/QGIS/table/tp_address.sqlite')

# which table information to select
sql_cmd = "SELECT Addr_key FROM 'AllBldgshTaipei2k20'"

row = pd.read_sql(sql= sql_cmd, con = connect)

def txt_split(name, breaksymbol):
    return name.split('breaksymbol')[0]

H2=[]; H3=[];

#change string type from number to traditional chinese
address_split      = row.split('_',2)

address_in_chinese = address_split[1].translate(CT2_HTAB_SECT_NUM)
    
H2.append(address_in_chinese)
#H2.append(address_split[3].translate(to_comment))
if '-' in address_split[2]:
    H3.append(address_split[2].translate(to_comment2))
else:
    H3.append(address_split[2].translate(to_comment))
'''
#%% export xlsx

df = pd.DataFrame(H2,columns=['H2'])
df.insert(1,'H3',H3)
writer = pd.ExcelWriter('D:/QGIS/table/address_new2.xlsx', engine='xlsxwriter')
df.to_excel(writer, sheet_name='address_new', index=False)
writer.save()

#pd.DataFrame.to_sql(con = connect, name='D:/QGIS/table/address_new2.xlsx', if_exists='replace', index = True)
