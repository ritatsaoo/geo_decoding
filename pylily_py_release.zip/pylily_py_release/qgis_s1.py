layer=iface.activeLayer()

features = layer.getFeatures()

print (layer.name())

for feature in features:
    print(feature.id())
    geom = feature.geometry()
    