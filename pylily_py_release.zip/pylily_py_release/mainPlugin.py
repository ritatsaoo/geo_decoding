# coding=utf-8
import os.path

from collections import namedtuple, defaultdict, OrderedDict
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtXml import *
from PyQt5.QtWidgets import *
from qgis.core import *


# initialize Qt resources from file resources.py
import importlib
import pylily.resources

import ctao_switch
              

class NSGPlugin:
    # save reference to the QGIS interface
    def __init__(self, iface):

        self.isOn = False
        self.db_path = None
        self.vlayer = []
        self.hiddenWidget = []
        self.iface = iface
        self.flag = False

    # create action that will start plugin configuration
    def initGui(self):
        from collections import OrderedDict
        path = ''':/plugins/LaLuna/{}.png'''
        funlist = OrderedDict([
                            ('management' , self.management),
                            ('play'       , self.play),
                            #('refresh'    , self.refresh),
                            #('earthquake' , self.earthquake),                                       
                            #('car'        , self.car),
                            #('bus'        , self.bus),
                            #('truck'      , self.truck),
                            #('traffic'    , self.traffic),
                            ('dashboard'  , self.dashboard),                                       
                            #('hospital'   , self.hospital),
                            #('robot'      , self.robot),
                            #('hawk1'      , self.hawk1),
                            #('laluna'     , self.laluna),
                            ('exit'       , self.exit)])

        self.actions = {}

        for name in funlist:
            icon_file = path .format(name)
            self.actions[name] = QAction(QIcon(icon_file), name , self.iface.mainWindow())
            self.actions[name].setObjectName(name)
            self.actions[name].setWhatsThis(name)
            self.actions[name].setStatusTip(name)
            self.actions[name].triggered.connect(funlist[name])
#            QObject(self.actions[name],    SIGNAL("triggered()"), funlist[name])
            self.iface.addToolBarIcon(self.actions[name])

            # connect to signal renderComplete which is emitted when canvas
            # rendering is done
			#QObject(self.iface.mapCanvas(), SIGNAL("renderComplete(QPainter *)"), self.render)
    
# add toolbar button and menu item
    #		self.iface.addPluginToMenu("&LaLuna plugins OFF", self.action1)
    #		self.iface.addPluginToMenu("&LaLuna plugins ON", self.action2)
    #		self.iface.addPluginToMenu("&LaLuna plugins RELOAD", self.action3)


    def play(self):
        importlib.reload(ctao_switch)  
        ctao_switch.play(self.iface)
        

    def exit(self):
        importlib.reload(ctao_switch)  
        ctao_switch.exit(self.iface)

    def refresh(self):
        importlib.reload(ctao_switch)  
        ctao_switch.refresh(self.iface)

    def car(self):
        importlib.reload(ctao_switch)  
        #layer = self.iface.addVectorLayer("K:\ctao_rawdata\data_3rd_NCDR\Road_ncdr_tt.shp", "Luna is moon", "ogr")
        ctao_switch.car(self.iface)

    def bus(self):
        importlib.reload(ctao_switch)  
        ctao_switch.bus(self.iface)

    def truck(self):
        importlib.reload(ctao_switch)  
        ctao_switch.truck(self.iface)

    def traffic(self):
        importlib.reload(ctao_switch)  
        ctao_switch.traffic(self.iface)

    def dashboard(self):
        importlib.reload(ctao_switch)  
        ctao_switch.dashboard(self.iface)

    def earthquake(self):
        importlib.reload(ctao_switch)  
        ctao_switch.earthquake(self.iface)

    def hawk1(self):
        importlib.reload(ctao_switch)  
        ctao_switch.hawk1(self.iface)
        
    def laluna(self):
        importlib.reload(ctao_switch)  
        ctao_switch.laluna(self.iface)

    def robot(self):
        importlib.reload(ctao_switch)  
        ctao_switch.robot(self.iface)

    def hospital(self):
        importlib.reload(ctao_switch)  
        ctao_switch.hospital(self.iface)		

    def management(self):
        importlib.reload(ctao_switch)  
        ctao_switch.management(self.iface)		

    def render(self, painter):
	    # use painter for drawing to map canvas
	    #a = 'do nothing'
        return

    def unload(self):
	    # remove the plugin menu item and icon
	    # disconnect form signal of the canvas
        #QObject.disconnect(self.iface.mapCanvas(), SIGNAL("renderComplete(QPainter *)"), self.render)
        return