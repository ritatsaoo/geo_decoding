import re
import pandas
import ctao2_foreach
from multiprocessing import Pool
from Lily.ctao2.ctao2_hostmetadata import hostmetadata
from Lily.ctao2.ctao2_database_alias import manidb
from Lily.ctao2.ctao2_database_alias import tickwatch


def GROUPING(database_path, table_dict):
    #pattern check and decomposition
    cputimewatch    = tickwatch()



if __name__ == '__console__' or __name__ == '__main__':
    import json
    cputimewatch    = tickwatch()

    database_path   = r'g:\NCREE_GIS\tgbs_data_cleanning_2020\tp_address.sqlite'
    mydb    = manidb(database_path)
    tableA           = 'data_tp_address_DECOMPOSITION_GA'
    tableB           = 'metadata_nsg_town'



    cputimewatch.tick()    