import sys


print (__file__)
for path in sys.path:
    print (path)