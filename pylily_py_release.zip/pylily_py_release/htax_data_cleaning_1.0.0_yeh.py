import re
import pandas
import ctao2_foreach
from multiprocessing import Pool
from Lily.ctao2.ctao2_hostmetadata import hostmetadata
from Lily.ctao2.ctao2_database_alias import manidb
from Lily.ctao2.ctao2_database_alias import tickwatch
##
## Cheng-Tao Yang 
## 定義數字等義均質化對應表
##
##
##
## KEYWORDS : str.maketrans

CT2_HTAB_SECT_NUM = str.maketrans (
    {
    '0':'○',
    'ㄧ':'一',
    '1':'一', 
    '2':'二',
    '3':'三',
    '4':'四',
    '5':'五',
    '6':'六',
    '7':'七',
    '8':'八',
    '9':'九',
#０-９ 65296-65305
    65296:'○',
    65297:'一', 
    65298:'二', 
    65299:'三', 
    65300:'四', 
    65301:'五', 
    65302:'六', 
    65303:'七', 
    65304:'八',
    65305:'九'
    })

CT2_HTAB_NUM = str.maketrans(
   {
    '○':'0',
    'ㄧ':'1',
    '一':'1', 
    '二':'2',
    '三':'3',
    '四':'4',
    '五':'5',
    '六':'6',
    '七':'7',
    '八':'8',
    '九':'9',
    '十':'10',
#０-９ 65296-65305
    65296:'0', 
    65297:'1', 
    65298:'2', 
    65299:'3', 
    65300:'4', 
    65301:'5', 
    65302:'6', 
    65303:'7', 
    65304:'8',
    65305:'9'
    })

## 定義所有地址的正規化表示式 
##
##
## HOUSETAX_ADDRESS_DECOMPOSITION_FACTORY
## 檢查是否符合正規化表示式(regular expression pattern) 如果符合則將subgroup 的特徵取出
## 不符合 傳回 'irregular
## 如果傳入值為 空字串 則 傳回 'none'
##
## KEYWORDS : regular expression

#irregular	303094.999	2773346.689	irregular	臺北市中山區圓山里004鄰新生北路三段８４巷４２號＊
#irregular_anychar	302179.436	2771642.295	臺北市大同區建泰里006鄰承德路ㄧ段６６號	臺北市大同區建泰里006鄰承德路ㄧ段６６號
## Origin Reqular expression pattern for anyCHAR
CT2_CHAR        = r'([\u4e00-\u9fa5０-９0-9Ａ-Ｗａ-ｓ\(\)\-〈―－—‾─〉（‧丶、，。～ˋ＆．‵）〔；：╱／〕○ㄧ＃;＊]*)'

## Origin Reqular expression pattern for NUMBER/ CITY/ ZONE/ LIE 
CT2_NUMP        = r'([臨近]{1})'
CT2_NUM_        = r'(?:[之―－—‾─\-]{1})'
CT2_NUMd        = r'([0-9０-９]{1,4})'
CT2_NUMD        = r'([0-9０-９一二三四五六七八九十○]{1,4})'
CT2_CITY        = r'(?:([\u4e00-\u9fa5]{2})[市縣]{1})'
CT2_ZONE        = r'(?:([\u4e00-\u9fa5]{2})[區鄉鎮]{1})'
CT2_LIE         = r'(?:([\u4e00-\u9fa5]{2})[里村]{1})'
CT2_LIN         = r'(?:([0-9０-９一二三四五六七八九十○]{1,4})鄰)'

## for ROAD (street)
CT2_ROAD        = r'(?:[\u4e00-\u9fa5]{1,4}(?:(?:路)|(?:大道)|(?:街)){1}(?:([0-9０-９ㄧ一二三四五六七八九十]{1})段){0,1})'
##
##reqular expression pattern for LAN (巷)
CT2_LANE1       = r'(?:([0-9０-９一二三四五六七八九十○]{1,4})巷)'
CT2_LANE2       = r'(?:([\u4e00-\u9fa5]{1,4})巷)'

CT2_LANE        = f'(?:{CT2_LANE1}|{CT2_LANE2})'
##
##reqular expression pattern for ALLEY (弄)
CT2_ALLEY       = r'(?:([(:?\u4e00-\u9fa5)|(?:[0-9０-９一二三四五六七八九十○)]{1,4})弄)'
##
CT2_MMNUMBER    = r'((?:(?:[0-9０-９]{1,3})?(?:[之―－—‾─]{1}(?:[0-9０-９]{1,4}))?(?:‧|丶|丶|、|至|，|。)?)+?號)'
##
##reqular expression pattern for (號/樓) 
##
## combination regular expression
##
CT2_NUM1             =f'(?:{CT2_NUMP}?{CT2_NUMD}(?:{CT2_NUM_}{CT2_NUMD})?號(?:{CT2_NUM_}{CT2_NUMD})?)'
CT2_FLOORG           =f'(?:{CT2_NUMD}樓(?:{CT2_NUM_}{CT2_NUMD})?)'
CT2_FLOORB           =f'(?:地下(?:{CT2_NUMD}[樓層])?(?:{CT2_NUM_}{CT2_NUMD})?)'

#class 1 of address regulaer expression

CT2_ADDR_REP1P       =f'^{CT2_CITY}{CT2_ZONE}{CT2_LIE}{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}$'
CT2_ADDR_REP1G       =f'^{CT2_CITY}{CT2_ZONE}{CT2_LIE}{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORG}$'
CT2_ADDR_REP1B       =f'^{CT2_CITY}{CT2_ZONE}{CT2_LIE}{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORB}$'
CT2_ADDR_REP1GA      =f'^{CT2_CITY}{CT2_ZONE}{CT2_LIE}{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORG}{CT2_CHAR}$'
CT2_ADDR_REP1BA      =f'^{CT2_CITY}{CT2_ZONE}{CT2_LIE}{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORB}{CT2_CHAR}$'
CT2_ADDR_REP1PA      =f'^{CT2_CITY}{CT2_ZONE}{CT2_LIE}{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_CHAR}$'

#class 2 of address regulaer expression
CT2_ADDR_REP2P       =f'^{CT2_CITY}?{CT2_ZONE}?{CT2_LIE}?{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}$'
CT2_ADDR_REP2G       =f'^{CT2_CITY}?{CT2_ZONE}?{CT2_LIE}?{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORG}$'
CT2_ADDR_REP2B       =f'^{CT2_CITY}?{CT2_ZONE}?{CT2_LIE}?{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORB}$'
CT2_ADDR_REP2GA      =f'^{CT2_CITY}?{CT2_ZONE}?{CT2_LIE}?{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORG}{CT2_CHAR}$'
CT2_ADDR_REP2BA      =f'^{CT2_CITY}?{CT2_ZONE}?{CT2_LIE}?{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORB}{CT2_CHAR}$'
CT2_ADDR_REP2PA      =f'^{CT2_CITY}?{CT2_ZONE}?{CT2_LIE}?{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_CHAR}$'

#class 3 of address regulaer expression
CT2_ADDR_REPANY      =f'^{CT2_CHAR}$'
#CT2_ADDR_REP_DEBUG   =f'^{CT2_CITY}{CT2_ZONE}{CT2_LIE}{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}$'


def fun1(arg):
    res1 = {}
    ans1 = arg.split('_')
    
    if len(ans1) == 4:
        res1['tc'] = 4
        res1['Addr_key'] = arg
        res1['H1'] = ans1[0]
        res1['O1'] = ''
        res1['H2'] = ans1[1].translate(CT2_HTAB_SECT_NUM)
        res1['Z1'] = ans1[2]
        match = re.match(CT2_NUM1 , ans1[3] )
        res1['H3'] = ','.join([ str(x or '') for x in match.groups()]) if match else ''
        res1['H_key']  = f'''{res1['H1']}{res1['H2']}({res1['H3']})'''


        res1['H4'] = match.groups()[1] if match else ''      
        res1['H_key2'] = f'''{res1['H1']}{res1['H2']}({res1['H4']})'''

    elif len(ans1) == 5:
        res1['tc'] = 5
        res1['Addr_key'] = arg
        res1['H1'] = ans1[0]
        res1['O1'] = ans1[1]
        res1['H2'] = ans1[2].translate(CT2_HTAB_SECT_NUM)
        res1['Z1'] = ans1[3]

        match = re.match(CT2_NUM1 , ans1[4] )
        res1['H3'] = ','.join([ str(x or '') for x in match.groups()]) if match else ''
        
        res1['H_key'] = f'''{res1['H1']}{res1['H2']}({res1['H3']})'''

        res1['H4'] = match.groups()[1] if match else ''      
        res1['H_key2'] = f'''{res1['H1']}{res1['H2']}({res1['H4']})'''

    else:
        res1['tc'] = 0
        res1['Addr_key'] = arg
        res1['H1'] = ''
        res1['O1'] = ''
        res1['H2'] = ''
        res1['Z1'] = ''
        res1['H3'] = ''
        res1['H_key'] = ''
        res1['H_key2'] = ''

    return res1

#    re.match()

def FACTORY(database_path):
    #pattern check and decomposition
    cputimewatch    = tickwatch()
    
    with manidb(database_path) as mydb:
        tp_alias = mydb.get_alias('AllBldgshTaipei2k20')
        df = tp_alias.read()
        
        mpool        = Pool(40)
        rdsetlist    = mpool.map(fun1, df.Addr_key.tolist())
    
        mpool.close()
        df2 = pandas.DataFrame(rdsetlist)

        df.insert(0, 'H_key', df2.H_key)
        df.insert(1, 'H_key2', df2.H_key2)

        mydb.get_alias('AllBldgshTaipei2k20_check_list').write(df)

        cputimewatch.tick()

    cputimewatch.tick()    

if __name__ == '__console__' or __name__ == '__main__':

    database_path = r'g:\NCREE_GIS\tgbs_data_cleanning_2020\tp_address.sqlite'
    FACTORY(database_path)
