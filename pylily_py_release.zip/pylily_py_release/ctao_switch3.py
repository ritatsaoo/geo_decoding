import re
import pandas

from Lily.ctao2.ctao2_database_mediator import manidb
from Lily.ctao2.ctao2_database_mediator import table as mtable 
from Lily.ctao2.ctao2_database_dialogue import table as dtable 

if __name__ == '__console__' or __name__ == '__main__' :
    import Lily.ctao.hostmetadata as chmd
    hobj1= chmd.hostmetadata()
    print ('check moudel Lily.ctao.hostmetadata')
    print (hobj1.callname, hobj1.hostname, hobj1.platform)
    print (hobj1.database, hobj1.warehouse, hobj1.factory)

    if hobj1.platform[:7] =='Windows': 
        tab1 = dtable('pick up a table')
        df = tab1.read()
        tab1.timer()
        print (df)