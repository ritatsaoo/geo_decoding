import csv
import numpy as np
import pandas as pd
from Lily.ctao2.ctao2_database_alias import manidb, alias, tickwatch
from multiprocessing import Pool

#%% CASE - lookup values and fillin the column
#arg list in sequence
#arg1 list_tract , 
#arg2 list_mbt, 
#arg3 (df2 , mbt damage probability), 
#arg4 'D4_probability' (column name), 
#arg5 list_floor_area, 
#arg6 list_floor_num, 
#arg7 'D4_area'

def lookup_value(arg1, arg2, arg3, arg4, arg5, arg6, arg7):
    
    df = arg3.set_index('Msa1_code')

    list0 = []; dic = {}

    for msa1, mbt in  zip (arg1, arg2) :
        probability = 0.0 
        #ind = float(msa1)
        ind = msa1
        if ind in df.index:
            probability = df.loc[ind, mbt]
        else:
            probability = -0.00001

        list0.append(probability)

    dic[arg4]  = list0
    dic[arg7]  = [ a*b for a, b, c in zip (list0, arg5, arg6)]

    list1 = []
    for a, b, c in zip (list0, arg5, arg6):
        list1.append ( '' if c == 0  else a*b/c)  

    dic[arg7 + '_per_floor'] = list1
    
    return dic


# STEP 1 - read column from table

if __name__ == '__console__' or __name__ == '__main__':
    cputime = tickwatch()
 
    # resource: database
    mydb    = manidb('G:/NCREE_GIS/Solution_Book/Project_C1_linxx_2020/20201214_ktt_address_olivia_v2.sqlite')

    df0     = mydb.get_alias('data_bldg_Keelung_msa1').read()
    df1     = mydb.get_alias('view_bldg_Keelung_msa1').read('nsg_key')
    df2     = mydb.get_alias('TgbsMtr_SCH66_MsaStrProb_D4').read()
    df3     = mydb.get_alias('TgbsMtr_SCH66_MsaStrProb_D5').read()
    
    cputime.tick()

    list_msa1          = df1.Addr_code.to_list()    
    list_mbt           = df1.MBT.to_list()
    list_floor_area    = df1.FloorArea.to_list()
    list_floor_num     = df1.NumFloors.to_list()
    
# STEP 2 - index calculation

    d4_probability     = lookup_value(list_msa1, list_mbt, df2, 'D4_probability', list_floor_area, list_floor_num, 'D4_area')
    d5_probability     = lookup_value(list_msa1, list_mbt, df3, 'D5_probability', list_floor_area, list_floor_num, 'D5_area')

    cputime.tick('probability calculation accomplished')
  
# STEP 3 - make table
    # 以view當dataframe加入基準,第一列會被吃掉
    df_d4_probability             = pd.DataFrame.from_dict(d4_probability, orient = 'columns')
    df0['D4_probability']         = df_d4_probability['D4_probability']
    df0['D4_area']                = df_d4_probability['D4_area']
    df0['D4_area_per_floor']      = df_d4_probability['D4_area_per_floor']

    df_d5_probability             = pd.DataFrame.from_dict(d5_probability, orient = 'columns')
    df0['D5_probability']         = df_d5_probability['D5_probability']
    df0['D5_area']                = df_d5_probability['D5_area']
    df0['D5_area_per_floor']      = df_d5_probability['D5_area_per_floor']
    
    cputime.tick('DataFrame accomplished')

# STEP 4 - write down table

    name = 'data_bldg_Keelung_SCH66_probability'

    tab1  = mydb.get_alias(name)
    
    tab1.write(df0)
 
    cputime.tick('Table writen down')

    

