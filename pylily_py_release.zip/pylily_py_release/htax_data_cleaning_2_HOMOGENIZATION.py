import csv
import pandas
##均質化 對應表
from Lily.ctao2.ctao2_database_mediator import tickwatch

CT2_HTAB_SECT_NUM = str.maketrans (
    {
    '0':'○',
    'ㄧ':'一',
    '1':'一', 
    '2':'二',
    '3':'三',
    '4':'四',
    '5':'五',
    '6':'六',
    '7':'七',
    '8':'八',
    '9':'九',
#０-９ 65296-65305
    65296:'○',
    65297:'一', 
    65298:'二', 
    65299:'三', 
    65300:'四', 
    65301:'五', 
    65302:'六', 
    65303:'七', 
    65304:'八',
    65305:'九'
    })

CT2_HTAB_NUM = str.maketrans(
   {
    '○':'0',
    'ㄧ':'1',
    '一':'1', 
    '二':'2',
    '三':'3',
    '四':'4',
    '五':'5',
    '六':'6',
    '七':'7',
    '八':'8',
    '九':'9',
    '十':'10',
#０-９ 65296-65305
    65296:'0', 
    65297:'1', 
    65298:'2', 
    65299:'3', 
    65300:'4', 
    65301:'5', 
    65302:'6', 
    65303:'7', 
    65304:'8',
    65305:'9'
    })


cputimewatch    = tickwatch()

def HTAX_ADDRESS_HOMOGENIZATION (arg):
    import re
    ########################################################
    from htax_data_cleaning_1_DECOMPOSITION import CT2_NUMD
    ########################################################

    key     = arg[0]
    val     = arg[1]
    rval    = arg[1].split(',')
    rdset   = {}   

    repat   = re.compile(CT2_NUMD)
    lane    = rval[6]
    match   = re.match(repat, lane)
   
    if match:
        rdset['H_LANE']   = lane.translate(CT2_HTAB_NUM)  
        rdset['C_LANE']   = ''  
    else:
        rdset['H_LANE']   = ''  
        rdset['C_LANE']   = lane  
    
    rdset['H_CITY']   = rval[0]
    rdset['H_ZONE']   = rval[1]
    rdset['H_LIE']    = rval[2]
    rdset['H_LIN']    = rval[3]
    rdset['H_ROAD']   = rval[4].translate(CT2_HTAB_SECT_NUM)
    rdset['H_SECT']   = rval[5].translate(CT2_HTAB_NUM)
    
    rdset['H_ALLEY']  = rval[7].translate(CT2_HTAB_NUM)
    rdset['H_NUMP']   = rval[8]
    rdset['H_NUM0']   = rval[9] .translate(CT2_HTAB_NUM)
    rdset['H_NUM1']   = rval[10].translate(CT2_HTAB_NUM)
    rdset['H_NUM2']   = rval[11].translate(CT2_HTAB_NUM)

    return (key, rdset )

def MPOOL_FACTORY(dataframe, INDEX_NAME, INPUT_COLUMN_NAME,  MAKE_FUNCTION):
    from multiprocessing import Pool
    from Lily.ctao2.ctao2_hostmetadata import hostmetadata

    mpool        = Pool(hostmetadata().cpu_code)
    rdsetlist    = mpool.map(MAKE_FUNCTION, dataframe[INPUT_COLUMN_NAME].items())
    mpool.close()

    import pandas
    df2 = pandas.DataFrame.from_dict( dict(rdsetlist), orient='index')   
    df2.index.names=[INDEX_NAME]

    return dataframe.merge(df2, on=INDEX_NAME)


def HOMOGENIZATION(database_path, table_dict):
    #type1_check()
    from Lily.ctao2.ctao2_database_mediator import manidb

    #regulare address express list
    rep_list = ['REP10', 'REP11', 'REP12', 'REP13', 'REP14', 'REP15', 
                'REP20', 'REP21', 'REP22', 'REP23', 'REP24', 'REP25'  ]
    mydb        = manidb(database_path)
    
    for table, cols in table_dict.items():
        itab        = mydb.get_alias(table)     #table (input data)

        otab        = mydb.get_alias(cols[2])   #cols[2] calculation_ouput_table

        ######
        dataframe   = itab.read(cols[0])        #cols[0] name of key(index column)
        cputimewatch.tick(f'read {itab.table_name}') 
        ######
        dataframe   = dataframe[dataframe['rep_level'].isin( rep_list ) ] 
        dataframe   = MPOOL_FACTORY(dataframe, cols[0], cols[1], HTAX_ADDRESS_HOMOGENIZATION )  #cols[1] calculation_ouput_table    
        cputimewatch.tick(f'mpool homogenization')
        ######
        otab.write(dataframe)
        cputimewatch.tick(f'write {otab.table_name}') 


if __name__ == '__console__' or __name__ == '__main__':

    database_path = r'g:\NCREE_GIS\tgbs_data_cleanning_2020\tp_address.sqlite'

    #                  table_name : [key_column_name, address_column_name, calculation_ouput_table]
    #                             
    table_dict    = { #'data_tp_housetax2019_DECOMPOSITION' : ['taxid'  , 'decomposition', 'data_tp_housetax2019_HOMOGENIZATION'], 
                      'data_tp_address_DECOMPOSITION_DEBUG'      : ['OGR_FID', 'decomposition', 'data_tp_address_HOMOGENIZATION'] }

    HOMOGENIZATION(database_path, table_dict)