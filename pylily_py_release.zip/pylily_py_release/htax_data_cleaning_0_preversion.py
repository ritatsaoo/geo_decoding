import re
##
## Cheng-Tao Yang 
## 定義所有地址的正規化表示式 
##
##
## ismatch_pattern 檢查是否符合正規化表示式(regular expression pattern) 如果符合則將subgroup 的特徵取出
## 不符合 傳回 'irregular
## 如果傳入值為 空字串 則 傳回 'none'
##
## KEYWORDS : regular expression
##
def ismatch_pattern (arg, repattern ):
    key = arg[0]
    val = arg[1]

    if val == '':
        return (key, 'none')

    match = re.match(repattern, val)

    if match:
        tg =  [ str(x or '') for x in match.groups() ]
        mtext =  ','.join( tg )
        return (key, mtext ) 
    else:
        return (key, 'irregular')


## reqular expression pattern for CITY (county)
def CHECK_FUN_CITY(addtext) : 
    return ismatch_pattern(addtext, re.compile(r'([\u4e00-\u9fa5]{2})(市|縣)'))

## reqular expression pattern for ZONE (town)
def CHECK_FUN_ZONE(addtext) : 
    return ismatch_pattern(addtext, re.compile(r'([\u4e00-\u9fa5]{2})(區|鄉|鎮)'))

## reqular expression pattern for LIE (tract/village)
def CHECK_FUN_LIE(addtext) : 
    return ismatch_pattern(addtext, re.compile(r'([\u4e00-\u9fa5]{2})(里|村)'))

##reqular expression pattern for LIN (鄰)
def CHECK_FUN_LIN(addtext) : 
    return ismatch_pattern(addtext, re.compile(r'([0-9]{1,3})(鄰)'))

##reqular expression pattern for ROAD (street)
def CHECK_FUN_ROAD(addtext) : 
    return ismatch_pattern(addtext, re.compile(r'([\u4e00-\u9fa5]{1,4}(?:(?:路)|(?:大道)|(?:街))(?:([一二三四五六七八九十])段)?)'))

##reqular expression pattern for LAN (巷)
def CHECK_FUN_LANE(addtext) : 
    return ismatch_pattern(addtext, re.compile(r'([(:?\u4e00-\u9fa5)|(?:０-９0-9)]{1,3})(巷)'))

##reqular expression pattern for ALLEY (弄)
def CHECK_FUN_ALLEY(addtext) : 
    return ismatch_pattern(addtext, re.compile(r'([０-９0-9]{1,3})(弄)'))

##reqular expression pattern for NUM (號)
def CHECK_FUN_NUM(addtext) : 
    return ismatch_pattern(addtext, re.compile(r'(臨?)([0-9０-９]{1,3})(?:(之)([0-9０-９]{1,4}))?(號)'))

##reqular expression pattern for FLOOR (地上樓層)
def CHECK_FUN_FLOOR(addtext) : 
    return ismatch_pattern(addtext, re.compile(r'^([一二三四五六七八九十０-９]{1,3})(樓)(?:(之)([一二三四五六七八九十０-９]{1,3}))?'))

##reqular expression pattern for FLOOR2 (地下樓層)
def CHECK_FUN_FLOOR2(addtext) : 
    return ismatch_pattern(addtext, re.compile(r'^(地下([一二三四五六七八九十０-９]{0,3})(樓|層)?)(?:(之)([一二三四五六七八九十０-９]{1,3}))?'))
##

def check_address_pattern(database_path, table_address):
    import ctao2_foreach 
    from Lily.ctao2.ctao2_database_mediator import manidb

    mydb        = manidb(database_path)
    ftab        = mydb.get_alias(table_address)
    dataframe   = ftab.read()    
    ftab.tick(f'read {ftab.table_name} data')

    dataframe['CITY_m']   = ctao2_foreach.for_series_mpool (dataframe.CITY, CHECK_FUN_CITY )
    ftab.tick('check all CITY')

    dataframe['ZONE_m']   = ctao2_foreach.for_series_mpool (dataframe.ZONE, CHECK_FUN_ZONE )
    ftab.tick('check all ZONE')

    dataframe['LIE_m']   = ctao2_foreach.for_series_mpool (dataframe.LIE, CHECK_FUN_LIE )
    ftab.tick('check all LIE')

    dataframe['LIN_m']   = ctao2_foreach.for_series_mpool (dataframe.LIN, CHECK_FUN_LIN )
    ftab.tick('check all LIN')

    dataframe['ROAD_m']   = ctao2_foreach.for_series_mpool (dataframe.ROAD, CHECK_FUN_ROAD )
    ftab.tick('check all ROAD')

    dataframe['LANE_m']  = ctao2_foreach.for_series_mpool (dataframe.LANE, CHECK_FUN_LANE )
    ftab.tick('check all LANE')

    dataframe['ALLEY_m'] = ctao2_foreach.for_series_mpool (dataframe.ALLEY, CHECK_FUN_ALLEY )
    ftab.tick('check all ALLEY')

    dataframe['NUM_m']   = ctao2_foreach.for_series_mpool(dataframe.NUM, CHECK_FUN_NUM )
    ftab.tick('check all NUM')

    dataframe['FLOOR_m'] = ctao2_foreach.for_series_mpool(dataframe.FLOOR, CHECK_FUN_FLOOR )   

    dataframe['FBASE_m'] = ctao2_foreach.for_series_mpool(dataframe.FLOOR, CHECK_FUN_FLOOR2)

    ftab.tick('check all FLOOR')

    dataframe2 = dataframe.drop(columns=['X','Y', 'CITY', 'ZONE', 'LIE', 'LIN', 'ROAD', 'LANE', 'ALLEY', 'NUM', 'FLOOR' ])

    table_decomposition = f'{table_address}_RE_DECOMPOSITION'
    mtab = mydb.get_alias(table_decomposition)
    mtab.write_with_index(dataframe2)
    mtab.tick(f'write down {table_decomposition} result data set')

    return table_decomposition

#SQLITE TRANSACTION for 群組統計 與 篩選不符正規化的
def grouping_transaction(database_path, table_address, table_decomposition):
    from Lily.ctao2.ctao2_database_mediator import manidb

    mydb        = manidb(database_path)
    transaction_LIE =  [f'''-- --step1 grouping_transaction LIE''',
                        f'''-- --({database_path}{table_address}{table_decomposition})--''',
                        f'''BEGIN TRANSACTION;''',
                        f'''drop table if exists {table_address}_irregular_LIE;''',

                        f'''create table {table_address}_irregular_LIE as 
                            select a.nsg_row_primkey, 
                                b.CITY || b.ZONE || b.LIE || b.LIN || b.ROAD || b.LANE || b.ALLEY  || b.NUM || b.FLOOR as ADDR,
                                b.CITY || b.ZONE || b.LIE as LIE_addr,
                                a.CITY_m, a.ZONE_m, a.LIE_m,
                                null CITY_user_revised_edition,
                                null ZONE_user_revised_edition,
                                null LIE_user_revised_edition   
                            from {table_decomposition} a left join {table_address} b
                            on a.nsg_row_primkey = b.ROWID
                            where a.CITY_M = 'irregular' or a.ZONE_M = 'irregular' or a.LIE_M = 'irregular';''',

                        f'''drop table if exists {table_address}_group_LIE;''',

                        f'''create table {table_address}_group_LIE  as 
                            select b.CITY || b.ZONE || b.LIE as LIE_addr, a.CITY_m, a.ZONE_m, a.LIE_m, count() as itemnum
                            from {table_decomposition} a left join {table_address} b
                            on a.nsg_row_primkey = b.ROWID
                            group by a.CITY_m, a.ZONE_m, a.LIE_m  order by  b.CITY , b.ZONE , b.LIE;''',
                        f'''COMMIT;''']

    transaction_ROAD = [f'''-- --step1 grouping_transaction ROAD ''',
                        f'''-- --({database_path}{table_address}{table_decomposition})--''',
                        f'''BEGIN TRANSACTION;''',
                        f'''drop table if exists {table_address}_irregular_ROAD;''',

                        f'''create table {table_address}_irregular_ROAD as 
                            select a.nsg_row_primkey, 
                                b.CITY || b.ZONE || b.LIE || b.LIN || b.ROAD || b.LANE || b.ALLEY  || b.NUM || b.FLOOR as ADDR,
                                b.ROAD || b.LANE || b.ALLEY as ROAD_addr,
                                a.ROAD_m, a.LANE_m, a.ALLEY_m,
                                null ROAD_user_revised_edition,
                                null LANE_user_revised_edition,
                                null ALLEY_user_revised_edition   
                            from {table_decomposition} a left join {table_address} b
                            on a.nsg_row_primkey = b.ROWID
                            where a.ROAD_M = 'irregular' or a.LANE_M = 'irregular' or a.ALLEY_M = 'irregular';''',

                        f'''drop table if exists {table_address}_group_ROAD;''',

                        f'''create table {table_address}_group_ROAD  as 
                            select b.ROAD || b.LANE || b.ALLEY as ROAD_addr, a.ROAD_m, a.LANE_m, a.ALLEY_m, count() as itemnum
                            from {table_decomposition} a left join {table_address} b
                            on a.nsg_row_primkey = b.ROWID
                            group by a.ROAD_m, a.LANE_m, a.ALLEY_m  order by b.ROAD, b.LANE, b.ALLEY;''',
                        f'''COMMIT;''']

    transaction_NUM = [ f'''-- --step1 grouping_transaction NUM ''',
                        f'''-- --({database_path}{table_address}{table_decomposition})--''',
                        f'''BEGIN TRANSACTION;''',
                        f'''drop table if exists {table_address}_irregular_NUM;''',

                        f'''create table {table_address}_irregular_NUM as 
                            select a.nsg_row_primkey, 
                                b.CITY || b.ZONE || b.LIE || b.LIN || b.ROAD || b.LANE || b.ALLEY || '!--[' || b.NUM || ']--!' || b.FLOOR as ADDR,
                                b.NUM, 
                                null NUM_user_revised_edition  
                            from {table_decomposition} a left join {table_address} b
                            on a.nsg_row_primkey = b.ROWID
                            where a.NUM_M = 'irregular' ;''',

                        f'''drop table if exists {table_address}_group_NUM;''',

                        f'''create table {table_address}_group_NUM  as 
                            select  b.NUM, a.NUM_m, count() as itemnum
                            from {table_decomposition} a left join {table_address} b
                            on a.nsg_row_primkey = b.ROWID
                            group by a.NUM_m  order by b.NUM;''',
                        f'''COMMIT;''']

    transaction_FLOOR = [ f'''-- --step1 grouping_transaction FLOOR ''',
                        f'''-- --({database_path}{table_address}{table_decomposition})--''',
                        f'''BEGIN TRANSACTION;''',
                        f'''drop table if exists {table_address}_irregular_FLOOR;''',

                        f'''create table {table_address}_irregular_FLOOR as 
                            select a.nsg_row_primkey, 
                                b.CITY || b.ZONE || b.LIE || b.LIN || b.ROAD || b.LANE || b.ALLEY ||  b.NUM || '!--[' || b.FLOOR || ']--!'  as ADDR,
                                b.FLOOR, 
                                null FLOOR_user_revised_edition  
                            from {table_decomposition} a left join {table_address} b
                            on a.nsg_row_primkey = b.ROWID
                            where a.FLOOR_M = 'irregular' and a.FBASE_M = 'irregular' ;''',

                        f'''drop table if exists {table_address}_group_FLOOR;''',

                        f'''create table {table_address}_group_FLOOR  as 
                            select  b.FLOOR, a.FLOOR_m, a.FBASE_m, count() as itemnum
                            from {table_decomposition} a left join {table_address} b
                            on a.nsg_row_primkey = b.ROWID
                            group by a.FLOOR_m, a.FBASE_m  order by b.FLOOR;''',
                        f'''COMMIT;''']

    mydb.transaction(transaction_LIE)
    mydb.transaction(transaction_ROAD)
    mydb.transaction(transaction_NUM)
    mydb.transaction(transaction_FLOOR)   
    return

def step1(database_path, table_address):
    table_decomposition = f'{table_address}_RE_DECOMPOSITION'

    table_decomposition = check_address_pattern(database_path, table_address)

    grouping_transaction(database_path, table_address, table_decomposition)


if __name__ == '__console__' or __name__ == '__main__':
    step1(r'g:\NCREE_GIS\TP_address\tp_address.sqlite', 'data_tp_address')