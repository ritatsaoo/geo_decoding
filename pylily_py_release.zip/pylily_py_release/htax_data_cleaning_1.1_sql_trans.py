import re
import pandas
import ctao2_foreach
from multiprocessing import Pool
from Lily.ctao2.ctao2_hostmetadata import hostmetadata
from Lily.ctao2.ctao2_database_alias import manidb
from Lily.ctao2.ctao2_database_alias import tickwatch


def GROUPING(database_path, table_dict):
    #pattern check and decomposition
    cputimewatch    = tickwatch()



if __name__ == '__console__' or __name__ == '__main__':
    import json
    cputimewatch    = tickwatch()

    database_path   = r'g:\NCREE_GIS\tgbs_data_cleanning_2020\tp_address.sqlite'
    table           = 'data_tp_address_DECOMPOSITION'
    table_town      = 'metadata_nsg_town'

    transaction_list = [f'''--ANALYZE--{table})--''',
                        f'''BEGIN TRANSACTION;''',
                        
                        #
                        #step 1
                        #
                        f'''drop view if exists {table}_G_KEY;''',
                        f'''drop table if exists {table}_GA;''', 

                        f'''CREATE VIEW {table}_G_KEY as 
                            SELECT  OGR_FID, X, Y, printf('(%s,%s)', "X", "Y") as G_KEY, 
                            "H1", "H2", "H3",  
                            "geom", "rep_level", "ADDR", "decomposition" 
                            FROM {table}''',

                        f'''CREATE table {table}_GA as 
                            SELECT count() num, 
                            printf('(%s,%s)', "X", "Y") as G_KEY,
                            "H1", "H2", "H3",
                            '1' as data_reliability,
                            min(substr(rep_level,4,2) ) R_KEY, 
                            OGR_FID,    X, Y,  
                            "geom", "rep_level", "ADDR", "decomposition" 
                            FROM {table}_G_KEY
                            group by G_KEY''',

                        f'''drop view if exists {table}_G_KEY;''',
                        #
                        ##step 2
                        #
                        f'''drop view if exists {table}_HA;''',
                        f'''drop view if exists {table}_HA_conflict_list;''',
                        f'''drop table if exists {table}_irreliability;''' , 

                        f'''CREATE view {table}_HA as 
                            SELECT count() num,  G_KEY, 
                            "H1", "H2", "H3"
                            FROM {table}_GA
                            group by H1 || H2 || H3''',

                        f'''CREATE view {table}_HA_conflict_list as 
                            SELECT num, G_KEY, H1, H2, H3
                            FROM {table}_HA
                            where H1 is null or H2 is null or H3 is null or num > 1 order by H1, H2, H3''',

                        f'''update {table}_GA 
                            set data_reliability ='conflict_(H_KEY)錯誤或同一個地址(H_KEY)多點位'
                            where
                            H1 || H2 || H3 in (select H1 || H2 || H3 from {table}_HA_conflict_list ); ''',

                        f'''create table {table}_irreliability as
                            select * from {table}_GA where data_reliability <> '1' order by H1, H2, H3''',

                        f'''drop view if exists {table}_HA;''',
                        f'''drop view if exists {table}_HA_conflict_list;''',

                        #
                        ##step 3
                        #
                        f'''drop table if exists {table}_GA2;''',

                        f'''create table {table}_GA2 as
                            select A.*, B.town_code  as town_code from  {table}_GA A
                            left join {table_town} B
                            on a.H1 = b.H1
                            where b.cnty_code = '63'; ''',

                        f'''COMMIT;''']

    with manidb(database_path) as mydb:
        mydb.transaction(transaction_list)
    cputimewatch.tick()    

                            #step 3
                        #f'''drop table if exists {table}_G1;''',
                        #f'''CREATE table {table}_G1 as 
                        #    SELECT * FROM {table}_GA where num = 1 ''',

                        #step 4
                        #f'''drop table if exists {table}_GM;''',
                        #f'''CREATE table {table}_GM as 
                        #    SELECT * FROM {table}_GA where num > 1 ''',