import sys
sys.path.append('C:/Users/ctyang/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins/pylily_pi')

def classFactory(iface):
  from pylily.mainPlugin import NSGPlugin
  return NSGPlugin(iface)

## any other initialisation needed
