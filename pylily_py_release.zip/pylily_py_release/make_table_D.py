import csv
import numpy as np
import pandas as pd
from datetime import datetime
from Lily.ctao2.ctao2_database_alias import manidb, alias, tickwatch
from multiprocessing import Pool
    
#%%
def make_dict(arg):
    datalist =[]
    file = open(arg, mode='r',encoding="utf-8")
    lines = file.readlines()
    for row in lines:
        dictionary = {}
        dictionary['HSN_CD']            = row[0]
        dictionary['HSN_LOSH']          = row[1:13]
        dictionary['LOCAT_ADDR']        = row[325:501]
        pos = row[1:530].find('C')
        #print(pos)
        dictionary['LOCAT_CD']          = row[(pos+1):(pos+71)]
        dictionary['OWNER_TP']          = row[(pos+78)]
        dictionary['HOU_BL_TP']         = row[(pos+79)]
        dictionary['ESTAB_LOSN_DATE']   = row[(pos+125):(pos+133)]
        dictionary['SPC_ADDR_MK']       = row[(pos+133)] 
        dictionary['USE_LIC_NO']        = row[(pos+134):(pos+147)]  
        
        datalist.append(dictionary)
        
    return datalist

if __name__ == '__console__' or __name__ == '__main__':
    cputime = tickwatch()
    mpool = Pool(8)    

    output = make_dict('G:/NCREE_GIS/tgbs_data_cleaning_2020/housetax/keelung/HOUF43D.txt')
    
    mpool.close()
    cputime.tick()

    df = pd.DataFrame(output)
    writer = pd.ExcelWriter('g:/ncree_gis/tgbs_data_cleaning_2020/housetax/keelung/HOUF43D_export.xlsx', engine='xlsxwriter')
    df.to_excel(writer, sheet_name ='data0', index = False)
    writer.save()
    cputime.tick('write down dataframe')

    




