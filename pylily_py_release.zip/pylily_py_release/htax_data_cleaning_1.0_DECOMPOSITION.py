import re
import pandas
import ctao2_foreach
from multiprocessing import Pool
from Lily.ctao2.ctao2_hostmetadata import hostmetadata
from Lily.ctao2.ctao2_database_alias import manidb
from Lily.ctao2.ctao2_database_alias import tickwatch
##
## Cheng-Tao Yang 
## 定義數字等義均質化對應表
##
##
##
## KEYWORDS : str.maketrans

CT2_HTAB_SECT_NUM = str.maketrans (
    {
    '0':'○',
    'ㄧ':'一',
    '1':'一', 
    '2':'二',
    '3':'三',
    '4':'四',
    '5':'五',
    '6':'六',
    '7':'七',
    '8':'八',
    '9':'九',
#０-９ 65296-65305
    65296:'○',
    65297:'一', 
    65298:'二', 
    65299:'三', 
    65300:'四', 
    65301:'五', 
    65302:'六', 
    65303:'七', 
    65304:'八',
    65305:'九'
    })

CT2_HTAB_NUM = str.maketrans(
   {
    '○':'0',
    'ㄧ':'1',
    '一':'1', 
    '二':'2',
    '三':'3',
    '四':'4',
    '五':'5',
    '六':'6',
    '七':'7',
    '八':'8',
    '九':'9',
    '十':'10',
#０-９ 65296-65305
    65296:'0', 
    65297:'1', 
    65298:'2', 
    65299:'3', 
    65300:'4', 
    65301:'5', 
    65302:'6', 
    65303:'7', 
    65304:'8',
    65305:'9'
    })

## 定義所有地址的正規化表示式 
##
##
## HOUSETAX_ADDRESS_DECOMPOSITION_FACTORY
## 檢查是否符合正規化表示式(regular expression pattern) 如果符合則將subgroup 的特徵取出
## 不符合 傳回 'irregular
## 如果傳入值為 空字串 則 傳回 'none'
##
## KEYWORDS : regular expression

#irregular	303094.999	2773346.689	irregular	臺北市中山區圓山里004鄰新生北路三段８４巷４２號＊
#irregular_anychar	302179.436	2771642.295	臺北市大同區建泰里006鄰承德路ㄧ段６６號	臺北市大同區建泰里006鄰承德路ㄧ段６６號
## Origin Reqular expression pattern for anyCHAR
CT2_CHAR        = r'([\u4e00-\u9fa5０-９0-9Ａ-Ｗａ-ｓ\(\)\-〈―－—‾─〉（‧丶、，。～ˋ＆．‵）〔；：╱／〕○ㄧ＃;＊]*)'

## Origin Reqular expression pattern for NUMBER/ CITY/ ZONE/ LIE 
CT2_NUMP        = r'([臨近]{1})'
CT2_NUM_        = r'(?:[之―－—‾─\-]{1})'
CT2_NUMd        = r'([0-9０-９]{1,4})'
CT2_NUMD        = r'([0-9０-９一二三四五六七八九十○]{1,4})'
CT2_CITY        = r'(?:([\u4e00-\u9fa5]{2})[市縣]{1})'
CT2_ZONE        = r'(?:([\u4e00-\u9fa5]{2})[區鄉鎮]{1})'
CT2_LIE         = r'(?:([\u4e00-\u9fa5]{2})[里村]{1})'
CT2_LIN         = r'(?:([0-9０-９一二三四五六七八九十○]{1,4})鄰)'

## for ROAD (street)
CT2_ROAD        = r'(?:[\u4e00-\u9fa5]{1,4}(?:(?:路)|(?:大道)|(?:街)){1}(?:([0-9０-９ㄧ一二三四五六七八九十]{1})段){0,1})'
##
##reqular expression pattern for LAN (巷)
CT2_LANE1       = r'(?:([0-9０-９一二三四五六七八九十○]{1,4})巷)'
CT2_LANE2       = r'(?:([\u4e00-\u9fa5]{1,4})巷)'

CT2_LANE        = f'(?:{CT2_LANE1}|{CT2_LANE2})'
##
##reqular expression pattern for ALLEY (弄)
CT2_ALLEY       = r'(?:([(:?\u4e00-\u9fa5)|(?:[0-9０-９一二三四五六七八九十○)]{1,4})弄)'
##
CT2_MMNUMBER    = r'((?:(?:[0-9０-９]{1,3})?(?:[之―－—‾─]{1}(?:[0-9０-９]{1,4}))?(?:‧|丶|丶|、|至|，|。)?)+?號)'
##
##reqular expression pattern for (號/樓) 
##
## combination regular expression
##
CT2_NUM1             =f'(?:{CT2_NUMP}?{CT2_NUMD}(?:{CT2_NUM_}{CT2_NUMD})?號(?:{CT2_NUM_}{CT2_NUMD})?)'
CT2_FLOORG           =f'(?:{CT2_NUMD}樓(?:{CT2_NUM_}{CT2_NUMD})?)'
CT2_FLOORB           =f'(?:地下(?:{CT2_NUMD}[樓層])?(?:{CT2_NUM_}{CT2_NUMD})?)'

#class 1 of address regulaer expression
CT2_ADDR_REP1P       =f'^{CT2_CITY}{CT2_ZONE}{CT2_LIE}{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}$'
CT2_ADDR_REP1G       =f'^{CT2_CITY}{CT2_ZONE}{CT2_LIE}{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORG}$'
CT2_ADDR_REP1B       =f'^{CT2_CITY}{CT2_ZONE}{CT2_LIE}{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORB}$'
CT2_ADDR_REP1GA      =f'^{CT2_CITY}{CT2_ZONE}{CT2_LIE}{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORG}{CT2_CHAR}$'
CT2_ADDR_REP1BA      =f'^{CT2_CITY}{CT2_ZONE}{CT2_LIE}{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORB}{CT2_CHAR}$'
CT2_ADDR_REP1PA      =f'^{CT2_CITY}{CT2_ZONE}{CT2_LIE}{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_CHAR}$'

#class 2 of address regulaer expression
CT2_ADDR_REP2P       =f'^{CT2_CITY}?{CT2_ZONE}?{CT2_LIE}?{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}$'
CT2_ADDR_REP2G       =f'^{CT2_CITY}?{CT2_ZONE}?{CT2_LIE}?{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORG}$'
CT2_ADDR_REP2B       =f'^{CT2_CITY}?{CT2_ZONE}?{CT2_LIE}?{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORB}$'
CT2_ADDR_REP2GA      =f'^{CT2_CITY}?{CT2_ZONE}?{CT2_LIE}?{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORG}{CT2_CHAR}$'
CT2_ADDR_REP2BA      =f'^{CT2_CITY}?{CT2_ZONE}?{CT2_LIE}?{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORB}{CT2_CHAR}$'
CT2_ADDR_REP2PA      =f'^{CT2_CITY}?{CT2_ZONE}?{CT2_LIE}?{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_CHAR}$'

#class 3 of address regulaer expression
CT2_ADDR_REPANY      =f'^{CT2_CHAR}$'
#CT2_ADDR_REP_DEBUG   =f'^{CT2_CITY}{CT2_ZONE}{CT2_LIE}{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}$'

CT2_ADDR_PATTERN_DICT   = { #'REP_DEBUG' :CT2_ADDR_REP_DEBUG,
                            'REP10' :CT2_ADDR_REP1P,
                            'REP11' :CT2_ADDR_REP1G,
                            'REP12' :CT2_ADDR_REP1B,
                            'REP13' :CT2_ADDR_REP1GA,
                            'REP14' :CT2_ADDR_REP1BA,
                            'REP15' :CT2_ADDR_REP1PA,
                            'REP20' :CT2_ADDR_REP2P,
                            'REP21' :CT2_ADDR_REP2G,
                            'REP22' :CT2_ADDR_REP2B,
                            'REP23' :CT2_ADDR_REP2GA,
                            'REP24' :CT2_ADDR_REP2BA,
                            'REP25' :CT2_ADDR_REP2PA,
                            'irregular_anychar' :CT2_ADDR_REPANY}

##
##
##
def GET_ADDR_PATTERN():
    return pandas.DataFrame.from_dict(CT2_ADDR_PATTERN_DICT, orient='index', columns=[ 'regular_expression'])
##
##
##
def HTAX_ADDRESS_DECOMPOSITION (arg):

    key         = arg[0]
    val         = arg[1]
    lanerepat   = re.compile(CT2_NUMD)
    
    rdset = {}
    if val == '':
            rdset['rep_level']          = 'none'
            rdset['decomposition']      = 'none'
    else:
        for rep_level, repatt in CT2_ADDR_PATTERN_DICT.items() :
            #DECOMPOSITION
            
            repattern       = re.compile(repatt)
            match           = re.match(repattern, val )

            #HOMOGENIZATION
            if match:
                rval                        = [ str(x or '') for x in match.groups()]
                rdset['rep_level']          = rep_level
                rdset['decomposition']      = ','.join( rval )

                if len(rval) > 6:
                    H_CITY      = rval[0]
                    H_ZONE      = rval[1]
                    #H_LIE    = rval[2]
                    #H_LIN    = rval[3]
                    H_ROAD      = rval[4].translate(CT2_HTAB_SECT_NUM)
                    #H_SECT   = rval[5].translate(CT2_HTAB_NUM)
                    lane        = rval[6]
                    #H_LANE     = lane.translate(CT2_HTAB_NUM)  if re.match(lanerepat, lane) else rval[7]
                    #H_ALLEY    = rval[8].translate(CT2_HTAB_NUM)
                    H_NUMP      = rval[9]
                    H_NUM0      = rval[10].translate(CT2_HTAB_NUM)
                    H_NUM1      = rval[11].translate(CT2_HTAB_NUM)
                    H_NUM2      = rval[12].translate(CT2_HTAB_NUM)

                    rdset['H1']    = f'''{H_CITY},{H_ZONE}'''
                    rdset['H2']    = f'''{H_ROAD}'''
                    rdset['H3']    = f'''{H_NUMP},{H_NUM0},{H_NUM1},{H_NUM2}'''
                    rdset['H4']    = f'''{H_NUM0}'''


                break
            else:
                rdset['rep_level']          = 'irregular'
                rdset['decomposition']      = 'irregular'

    return (key, rdset)
##
##
##
def MPOOL_FACTORY(dataframe, INDEX_NAME, INPUT_COLUMN_NAME,  MAKE_FUNCTION):
    mpool        = Pool(hostmetadata().cpu_code)
    rdsetlist    = mpool.map(MAKE_FUNCTION, dataframe[INPUT_COLUMN_NAME].items())
    mpool.close()
    
    df2 = pandas.DataFrame.from_dict( dict(rdsetlist), orient='index')   
    df2.index.names=[INDEX_NAME]

    return dataframe.merge(df2, on=INDEX_NAME)
##
##
##
def LOOP_FACTORY(dataframe, INDEX_NAME, INPUT_COLUMN_NAME,  MAKE_FUNCTION):
   
    rset=[]
    for arg in dataframe[INPUT_COLUMN_NAME].items():
        rset.append(MAKE_FUNCTION(arg))

    rdsetlist =   pandas.Series( dict(rset) ) 

    df2 = pandas.DataFrame.from_dict( dict(rdsetlist), orient='index')   
    df2.index.names=[INDEX_NAME]

    return dataframe.merge(df2, on=INDEX_NAME)
##
##
##
def STAT_RESULT(database_path, table_dict):

    for origintable, cols in table_dict.items():

        table           = cols[2]

        transaction_list = [f'''-- --({database_path}{table})--''',
                            f'''BEGIN TRANSACTION;''',

                            #f'''drop table if exists {table}_group;''',
                            #f'''create table {table}_group as select count() num , rep_level from {table} group by rep_level; ''',
                            
                            #f'''drop table if exists {table}_irregular;''',
                            #f'''create table {table}_irregular as select * from {table} where rep_level like '%irregular%'; ''',

                            f'''drop table if exists {table}_TC;''',
                            f'''create table {table}_TC as 
                                select printf('%s%s(%s)', b.town_code, H2, H3) as H_key,
                                printf('%s%s(%s)', b.town_code, H2, H4) as H_key2,
                                "ADDR", "X", "Y", "ZONE", "LIE", "LIN", "CITY", "ROAD", "LANE", "ALLEY", 
                                "NUM", "FLOOR", "OGR_FID", a.geom, "rep_level", "decomposition"
                                from {table}  a left join metadata_nsg_town b on a.H1 = b.H1 ''',
                            f'''COMMIT;''']


        with manidb(database_path) as mydb:
            mydb.transaction(transaction_list)

def DECOMPOSITION(database_path, table_dict):
    #pattern check and decomposition
    cputimewatch    = tickwatch()

    with manidb(database_path) as mydb:
        mydb.get_alias('rep_table').write_with_index(GET_ADDR_PATTERN())
        
        for table, cols in table_dict.items():
            itab        = mydb.get_alias(table)
            otab        = mydb.get_alias(cols[2])   #cols[2] calculation_ouput_table
            dataframe   = itab.read(cols[0])        #cols[0] name of key(index column)     
#            dataframe   = LOOP_FACTORY(dataframe, cols[0], cols[1], HTAX_ADDRESS_DECOMPOSITION )  #cols[1] calculation_ouput_table    
            dataframe   = MPOOL_FACTORY(dataframe, cols[0], cols[1], HTAX_ADDRESS_DECOMPOSITION )  #cols[1] calculation_ouput_table    
            otab.write_with_index(dataframe)

    cputimewatch.tick()    

if __name__ == '__console__' or __name__ == '__main__':

    database_path = r'g:\NCREE_GIS\tgbs_data_cleanning_2020\tp_address.sqlite'

    #                  table_name : [key_column_name, address_column_name, calculation_ouput_table]
    #                             
    table_dict    = {  'data_tp_address'      : ['OGR_FID', 'ADDR'   , 'data_tp_address_DECOMPOSITION'] }
#    DECOMPOSITION(database_path, table_dict)
    STAT_RESULT(database_path, table_dict)
