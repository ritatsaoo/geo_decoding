import os
from tkinter import *
from tkinter.ttk import *



def myFunction(selFeatures):
    print('in myFun')
    print (str(len(selFeatures)) + " features were selected: " + str(selFeatures))
    return

def management(iface):
    ui = button1()
    #print (ui.mydb.tables())

    print ('ct - yang management4')
    return

def play(iface):
    data = {}
    exceptionWidget = ['Layers', 'mPluginToolBar', 'mMapNavToolBar']
    hiddenType = ['''<class 'PyQt5.QtWidgets.QDockWidget'>''', '''<class 'PyQt5.QtWidgets.QToolBar'>''']

    for widget in iface.mainWindow().children():
        objtype = str(type(widget))
        if objtype in hiddenType:
            data[widget.objectName()] = [objtype, widget.isVisible()]
            if widget.isVisible() and widget.objectName() not in  exceptionWidget: 
                widget.hide()

    df = pd.DataFrame.from_dict(data, orient = 'index', columns=['objtype','isVisible'])
    df.to_sql('data_tab_qgis3_widget', medi.dbin.connect, if_exists='replace')

    for x in iface.mainWindow().findChildren(QMenuBar):
        #for i, item in enumerate(x.actions()):
        #    print i+1, 'name: ', item.icon().name()
        for item in x.actions():
            if item.text().replace('&','') in ['Raster', 'Web', 'Processing']:
               item.setVisible(False)
            #other menu item
            #['Edit','View','Layer','Settings','Plugins','Vector','Database','Help']
    return

def exit(iface):
    print('exit')

    return
#	project = QgsProject.instance()
#	project.clear()


def play1(iface):
	project = QgsProject.instance()
	project.clear()
	canvas = iface.mapCanvas()

	layer_dict ={'most_106_freeway': None, 'seg_road_freeway_nsg': None \
				 , 'poi_road_etcgantry_nsg': None, 'most_106_county': None ,'most_106_gantry': None }

	for tab_name in layer_dict:
		uri = QgsDataSourceURI()
		uri.setDatabase(LMediator.dict['database'])
		uri.setSrid('3826')
		uri.setDataSource( '', tab_name , 'geom')
		layer = QgsVectorLayer( uri.uri(), tab_name, 'spatialite')
		QgsMapLayerRegistry.instance().addMapLayer(layer, False)
		root = QgsProject.instance().layerTreeRoot()
		root.addLayer(layer)
		layer_dict[tab_name] = layer
	
	#expr = QgsExpression("road_number in (1,2,3,5, 66, 68, 64, 65,62, 72)")
	#it = layer.getFeatures(QgsFeatureRequest(expr))
	#ids = [i.id() for i in it] #select only the features for which the expression is true
	#layer.setSelectedFeatures(ids)
	#canvas.zoomToSelected(layer)
	#layer.setSelectedFeatures([])


#
#    uri = QgsDataSourceURI()
#    uri.setDatabase(LMediator.dbfilename)
#    uri.setSrid('4326')
#    uri.setDataSource('', 'bnd_twn_tract_teles2015',  'geom' )
#    layer = QgsVectorLayer(uri.uri(), 'mylayer1', 'spatialite')
#    
#    QgsMapLayerRegistry.instance().addMapLayer(layer, False)
#    
#    root.addLayer(layer)

def refresh(iface):
	project = QgsProject.instance()
	project.clear()
	
	tab_freeway = 'seg_road_freeway_nsg';

	uri = QgsDataSourceURI()
	uri.setDatabase(LMediator.dict['database'])
	uri.setSrid('3826')
	uri.setDataSource( '', tab_freeway , 'geom')

	layer = QgsVectorLayer( uri.uri(), tab_freeway, 'spatialite')
	QgsMapLayerRegistry.instance().addMapLayer(layer, False)
	root = QgsProject.instance().layerTreeRoot()
	root.addLayer(layer)

def earthquake(iface):
    print ('seismic design 2')

def car(iface):
    #import Lily.blacksmith.melt_vd as mvd

    #bsmith  = mvd.melt_vd()
    #bsmith.create_table_tpec_vd()
    #layers = QgsProject.instance().mapLayersByName(bsmith.tablelist['tpec_vd'])

    #if len(layers) >= 1:
    #    for lyr in layers:
    #        iface.layerTreeView().refreshLayerSymbology(lyr.id())
    #else:
    #    layer = iface.addVectorLayer(bsmith.databasename, bsmith.tablelist['tpec_vd'], 'ogr')

    print('car')

def bus(iface):
    print ('hi bus')

def truck(iface):
    print ('truck ')

def traffic(iface):
    print ('traffic')
    
def dashboard(iface):
    ui = asktablename()
    print (ui.mydb.tables())
        
def hospital(iface):
    print ('')
    
def robot(iface):
    print ('')


def hawk1(iface):
    print ('')

def laluna(iface):
    print ('laluna')

def action_instance(iface):
    QMessageBox.information(None, "DEBUG:", name)
    print (name)

class button1:
    def __init__(self, nametext ='hello' ) :
        self.label    = {}
        self.entry    = {}
        self.button   = {}
        self.values   = {}

 
        self.dirname        = os.getcwd()
        self.mainframe      = Tk()
        self.mainframe.title(nametext)
        
        icon_path = r'''C:\Users\ctyang\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\pylily\icon\{}'''

        photo = PhotoImage(file = icon_path.format('management.png') ) 

        self.button_ok        = Button(self.mainframe, text = 'ok', image = photo, command = self.button_fun_ok )
        self.button_ok.grid   (row = 1 , column = 1, stick = 'nesw', padx = 2, pady = 2) 

        self.button_2         = Button(self.mainframe, text = 'ok', image = photo, command = self.button_fun_2 )
        self.button_ok.grid   (row = 1 , column = 2, stick = 'nesw') 

        self.mainframe.mainloop()

    def button_fun_ok(self):

        #for key in self.entry :
        #    self.values[key] =  self.entry[key].get()
        self.mainframe.destroy()
        
    def button_fun_2(self):

        laluna( 1 )

if __name__ == '__console__' or __name__ == '__main__':
    ui=button1()

