#irregular	303094.999	2773346.689	irregular	臺北市中山區圓山里004鄰新生北路三段８４巷４２號＊
#irregular_anychar	302179.436	2771642.295	臺北市大同區建泰里006鄰承德路ㄧ段６６號	臺北市大同區建泰里006鄰承德路ㄧ段６６號
## Origin Reqular expression pattern for anyCHAR
CT2_CHAR        = r'([\u4e00-\u9fa5０-９0-9Ａ-Ｗａ-ｓ\(\)\-〈―－—‾─〉（‧丶、，。～ˋ＆．‵）〔；：╱／〕○ㄧ＃;＊]*)'

## Origin Reqular expression pattern for NUMBER/ CITY/ ZONE/ LIE 
CT2_NUMP        = r'([臨近]{1})'
CT2_NUM_        = r'(?:[之―－—‾─\-]{1})'
CT2_NUMd        = r'([0-9０-９]{1,4})'
CT2_NUMD        = r'([0-9０-９一二三四五六七八九十○]{1,4})'
CT2_CITY        = r'(?:([\u4e00-\u9fa5]{2})[市縣]{1})'
CT2_ZONE        = r'(?:([\u4e00-\u9fa5]{2})[區鄉鎮]{1})'
CT2_LIE         = r'(?:([\u4e00-\u9fa5]{2})[里村]{1})'
CT2_LIN         = r'(?:([0-9０-９一二三四五六七八九十○]{1,4})鄰)'

## for ROAD (street)
CT2_ROAD        = r'(?:[\u4e00-\u9fa5]{1,4}(?:(?:路)|(?:大道)|(?:街)){1}(?:([0-9０-９ㄧ一二三四五六七八九十]{1})段){0,1})'
##
##reqular expression pattern for LAN (巷)
CT2_LANE        = r'(?:([\u4e00-\u9fa5]{1,4})巷)|(?:([0-9０-９一二三四五六七八九十○)]{1,4})巷)'
##
##reqular expression pattern for ALLEY (弄)
CT2_ALLEY       = r'(?:([(:?\u4e00-\u9fa5)|(?:[0-9０-９一二三四五六七八九十○)]{1,4})弄)'
##
CT2_MMNUMBER    = r'((?:(?:[0-9０-９]{1,3})?(?:[之―－—‾─]{1}(?:[0-9０-９]{1,4}))?(?:‧|丶|丶|、|至|，|。)?)+?號)'
##
##reqular expression pattern for (號/樓) 
##
## combination regular expression
##
CT2_NUM1             =f'(?:{CT2_NUMP}?{CT2_NUMD}(?:{CT2_NUM_}{CT2_NUMD})?號(?:{CT2_NUM_}{CT2_NUMD})?)'
CT2_FLOORG           =f'(?:{CT2_NUMD}樓(?:{CT2_NUM_}{CT2_NUMD})?)'
CT2_FLOORB           =f'(?:地下(?:{CT2_NUMD}[樓層])?(?:{CT2_NUM_}{CT2_NUMD})?)'

#class 1 of address regulaer expression
CT2_ADDR_REP1P       =f'^{CT2_CITY}{CT2_ZONE}{CT2_LIE}{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}$'
CT2_ADDR_REP1G       =f'^{CT2_CITY}{CT2_ZONE}{CT2_LIE}{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORG}$'
CT2_ADDR_REP1B       =f'^{CT2_CITY}{CT2_ZONE}{CT2_LIE}{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORB}$'
CT2_ADDR_REP1GA      =f'^{CT2_CITY}{CT2_ZONE}{CT2_LIE}{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORG}{CT2_CHAR}$'
CT2_ADDR_REP1BA      =f'^{CT2_CITY}{CT2_ZONE}{CT2_LIE}{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORB}{CT2_CHAR}$'
CT2_ADDR_REP1PA      =f'^{CT2_CITY}{CT2_ZONE}{CT2_LIE}{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_CHAR}$'

#class 2 of address regulaer expression
CT2_ADDR_REP2P       =f'^{CT2_CITY}?{CT2_ZONE}?{CT2_LIE}?{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}$'
CT2_ADDR_REP2G       =f'^{CT2_CITY}?{CT2_ZONE}?{CT2_LIE}?{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORG}$'
CT2_ADDR_REP2B       =f'^{CT2_CITY}?{CT2_ZONE}?{CT2_LIE}?{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORB}$'
CT2_ADDR_REP2GA      =f'^{CT2_CITY}?{CT2_ZONE}?{CT2_LIE}?{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORG}{CT2_CHAR}$'
CT2_ADDR_REP2BA      =f'^{CT2_CITY}?{CT2_ZONE}?{CT2_LIE}?{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_FLOORB}{CT2_CHAR}$'
CT2_ADDR_REP2PA      =f'^{CT2_CITY}?{CT2_ZONE}?{CT2_LIE}?{CT2_LIN}?({CT2_ROAD}{CT2_LANE}?{CT2_ALLEY}?){CT2_NUM1}{CT2_CHAR}$'

#class 3 of address regulaer expression
CT2_ADDR_REPANY      =f'^{CT2_CHAR}$'


#CT2_ADDR_PATTERN_DICT   = { 'REP10' :CT2_ADDR_REP1P,
#                            'REP11' :CT2_ADDR_REP1G,
#                            'REP12' :CT2_ADDR_REP1B,
#                            'REP13' :CT2_ADDR_REP1GA,
#                            'REP14' :CT2_ADDR_REP1BA,
#                            'REP15' :CT2_ADDR_REP1PA,

#                            'REP20' :CT2_ADDR_REP2P,
#                            'REP21' :CT2_ADDR_REP2G,
#                            'REP22' :CT2_ADDR_REP2B,
#                            'REP23' :CT2_ADDR_REP2GA,
#                            'REP24' :CT2_ADDR_REP2BA,
#                            'REP25' :CT2_ADDR_REP2PA,
#                            'irregular_anychar' :CT2_ADDR_REPANY}


if __name__ == '__console__' or __name__ == '__main__':
    

    glb = globals()


