import csv
import numpy as np
import pandas as pd

#%% text conversion
CT2_HTAB_SECT_NUM = str.maketrans (
    {
    '0':'○',
    'ㄧ':'一',
    '1':'一', 
    '2':'二',
    '3':'三',
    '4':'四',
    '5':'五',
    '6':'六',
    '7':'七',
    '8':'八',
    '9':'九',
#０-９ 65296-65305
    65296:'○',
    65297:'一', 
    65298:'二', 
    65299:'三', 
    65300:'四', 
    65301:'五', 
    65302:'六', 
    65303:'七', 
    65304:'八',
    65305:'九'
    })

CT2_HTAB_NUM = str.maketrans(
   {
    '○':'0',
    'ㄧ':'1',
    '一':'1', 
    '二':'2',
    '三':'3',
    '四':'4',
    '五':'5',
    '六':'6',
    '七':'7',
    '八':'8',
    '九':'9',
    '十':'10',
#０-９ 65296-65305
    65296:'0', 
    65297:'1', 
    65298:'2', 
    65299:'3', 
    65300:'4', 
    65301:'5', 
    65302:'6', 
    65303:'7', 
    65304:'8',
    65305:'9'
    })
to_comment = str.maketrans(
   {
    '號' :',,'
    })
to_comment2 = str.maketrans(
   {
    '-'  :',',
    '號' :','
    })

#%% read csv

from Lily.ctao2.ctao2_database_alias import manidb, alias, tickwatch
from multiprocessing import Pool

def fun0(arg):
    res1 = {}
    ans1 = arg.split('_')
    
    if len(ans1) == 4:
        # H1 = Town_code
        # H2 = Road_name
        # H3 = Door_number
        # O1 = Village_name
        # Z1 = uncertain_name
        res1['H1'] = ans1[0]
        res1['O1'] = ''
        res1['H2'] = ans1[1].translate(CT2_HTAB_SECT_NUM)
        res1['Z1'] = ans1[2]
        if '-' in arg:
            res1['H3'] = ','+ ans1[3].translate(to_comment2)
        else:
            res1['H3'] = ','+ ans1[3].translate(to_comment)
        if len(ans1[2])>=1:
            res1['Q1'] = 'X'
        else:
            res1['Q1'] = 'O'

    elif len(ans1) == 5:
        res1['H1'] = ans1[0]
        res1['O1'] = ans1[1]
        res1['H2'] = ans1[2].translate(CT2_HTAB_SECT_NUM)
        res1['Z1'] = ans1[3]
        if '-' in arg:
            res1['H3'] = ','+ ans1[3].translate(to_comment2)
        else:
            res1['H3'] = ','+ ans1[3].translate(to_comment)
        if len(ans1[2])>=1:
            res1['Q1'] = 'X'
        else:
            res1['Q1'] = 'O'

    else:
        res1['H1'] = ''
        res1['O1'] = ''
        res1['H2'] = ''
        res1['Z1'] = arg
        res1['H3'] = ''
        res1['Q1'] = 'X'
    return res1

if __name__ == '__console__' or __name__ == '__main__':
    cputime = tickwatch()
    mydb = manidb('G:/NCREE_GIS/tgbs_data_cleaning_2020/tp_address.sqlite')
    #resource
    tab0 = mydb.get_alias('AllBldgshTaipei2k20')
    #outcome
    tab1 = mydb.get_alias('data_calc_result')
    #comparing resource
    tab2 = mydb.get_alias('data_tp_address_DECOMOSITION_GA2')
 
    df0  = tab0.read()
    df2  = tab2.read()

    cputime.tick()

    #read Addr_key column
    list1 = df0.Addr_key.to_list()

    list2 = df2.Addr_key.to_list()

    mpool = Pool(8)
    address_break = mpool.map(fun0, list1)
    #address_break.append({'Tract':df2.Tract.to_list()})
    mpool.close()
    
    cputime.tick()

    df = pd.DataFrame.from_dict(address_break, orient = 'columns')

    df0['H1'] = df['H1']
    df0['H2'] = df['H2']
    df0['H3'] = df['H3']

    df0 = df0.drop(columns=['Tm97_x', 'Tm97_y', 'Addr_code'])

    #df.insert(6,'Tract',df2.Tract.to_list())
    #df.insert(7,'StrType',df2.StrType.to_list())
    #df.insert(8,'BussArea',df2.BussArea.to_list())
    #df.insert(9,'HousArea',df2.HousArea.to_list())
    cputime.tick('calculation accomplished')

    tab1.write(df0)
 
    cputime.tick('write down dataframe')

