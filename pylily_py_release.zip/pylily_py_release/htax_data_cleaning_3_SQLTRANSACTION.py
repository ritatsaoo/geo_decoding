#SQLITE TRANSACTION for 群組統計 與 篩選不符正規化的
def grouping_transaction(database_path, table_address, table_target):

    from Lily.ctao2.ctao2_database_mediator import manidb

    mydb        = manidb(database_path)

#  "ROAD" ||  '_' || "NUMP" ||  '_' || "NUM0" ||  '_' || "NUM1" ||  '_' || "NUM2" as  addrkey,

    transaction_list = [f'''-- --({database_path}{table_address}{table_target})--''',
                        f'''BEGIN TRANSACTION;''',
                        f'''drop table if exists {table_target};''',

                        f'''create table {table_target} as 
                            select OGR_FID, geom, count() num,

                            ROAD,
                            printf('%01s,%04d,%04d,%04d', NUMP, NUM0, NUM1, NUM2) as addrkey,
                            min(cast (substr(rep_level,4,2)  as integer)) as rep_level,
                            addr as address, decomposition
                            from {table_address} 
                            where length(rep_level) = 5  group by geom''',
                        f'''COMMIT;''']

    mydb.transaction(transaction_list)
    return

if __name__ == '__console__' or __name__ == '__main__':
    grouping_transaction(r'g:\NCREE_GIS\TP_address\tp_address.sqlite', r'data_tp_address_HOMOGENIZATION', r'data_tp_address_HOMOGENIZATION_geom' )