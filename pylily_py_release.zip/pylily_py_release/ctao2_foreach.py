

def for_series_mpool(arg_series, arg_fun ):
    import pandas
    from multiprocessing import Pool
    from Lily.ctao2.ctao2_hostmetadata import hostmetadata
    hostm   = hostmetadata()
    mpool   = Pool(hostm.cpu_code)
    rset    = mpool.map(arg_fun, arg_series.items())
    mpool.close()
  
    return  pandas.Series( dict(rset) ) 

def for_series_loop(arg_series, arg_fun ):
    import pandas
   
    rset=[]
    for arg in arg_series.items():
        rset.append(arg_fun(arg))

    return  pandas.Series( dict(rset) ) 

