import csv
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from Lily.ctao2.ctao2_database_alias import manidb, alias, tickwatch
from multiprocessing import Pool

#%% CASE - calculate each index in streetblock

# 人口密度 = 人口數/基地面積
def population_density(ziparg):
    arg1 = ziparg [0]
    arg2 = ziparg [1]
    res1 = {}
    if arg2 is None:
        res1['pop_dens'] = None
    else:
        res1['pop_dens'] = arg1 / arg2
    return res1

#容積率 = 建物總樓地板面積/基地面積
def floor_area_ratio(ziparg):
    arg1 = ziparg [0]
    arg2 = ziparg [1]
    res1 = {}
    if arg2 is None:
        res1['floor_area_ratio'] = None
    else:
        res1['floor_area_ratio'] = arg1 / arg2
    return res1

#住宅比例 = 住宅用面積/建物總樓地板面積
def housing_ratio(ziparg):
    arg1 = ziparg [0]
    arg2 = ziparg [1]
    res1 = {}
    if arg2 is None:
        res1['housing_ratio'] = None
    else:
        res1['housing_ratio'] = arg1 / arg2
    return res1

# make list of lists to list of pure values
def pure_list(arg1):

    list0 =[]; 
    for value in arg1:
        for i in value:
            list0.append(i)                    
    return list0

# 指數設定
def make_degree(arg1, arg2):
    # list is named as arg1,            i.e. df_pop['pop_dens']
    # new_column_name is named as arg2, i.e. 'pop_dens_degree'  

    # except null or nan
    value_q3 = np.nanpercentile(arg1, 75, axis=0)
    value_q1 = np.nanpercentile(arg1, 25, axis=0)
    print(arg2, 'Q3 =', value_q3, '; Q1 =', value_q1)

    list0 =pure_list(arg1)
    list = []
    for value in list0:
        if value >= value_q3:  
            list.append(3)
        elif value < value_q3 and value >= value_q1:
            list.append(2)
        elif value < value_q1 and value > 0:
            list.append(1)
        else:
            list.append(0)
    res1 = {};  res1[arg2] = list
    return res1

# STEP 1 - read column from table

if __name__ == '__console__' or __name__ == '__main__':
    cputime = tickwatch()
 
    # resource: database
    mydb    = manidb('G:/NCREE_GIS/Solution_Book/Project_C1_linxx_2020/ktt_address_bldg_probability.sqlite')

    df1     = mydb.get_alias('streetblock_sbldg_Keelung1').read()
    
    cputime.tick()

    # for population_density
    list_pop        = df1.population_cnt.to_list()    
    list_land_area  = df1.LandArea.to_list()
    arg_list_pop    = zip (list_pop, list_land_area)

    # for housing_ratio
    list_house_area = df1.AllHousArea.to_list()
    list_floor_area = df1.AllFloorArea.to_list()
    arg_list_house  = zip (list_house_area, list_floor_area)
    
    # for floor_area_ratio
    arg_list_floor  = zip (list_floor_area, list_land_area)

# STEP 2 - index calculation
    mpool = Pool(4)

    pop   = mpool.map(population_density, arg_list_pop)

    floor = mpool.map(floor_area_ratio, arg_list_floor)
    
    house = mpool.map(housing_ratio, arg_list_house)

    mpool.close()

# STEP 3 - make table
    df_pop   = pd.DataFrame.from_dict(pop, orient = 'columns')
    df1['population_density'] = df_pop['pop_dens']

    df_floor = pd.DataFrame.from_dict(floor, orient = 'columns')
    df1['floor_area_ratio']   = df_floor['floor_area_ratio']

    df_house = pd.DataFrame.from_dict(house, orient = 'columns')
    df1['housing_ratio']      = df_house['housing_ratio']

# STEP 4 - make degree

    pop_dense_degree                  = make_degree(df_pop.values.tolist(), 'population_density_degree')
    df_pop_degree                     = pd.DataFrame.from_dict(pop_dense_degree, orient = 'columns')
    df1['population_density_degree']  = df_pop_degree['population_density_degree']
  
    floor_area_degree                 = make_degree(df_floor.values.tolist(), 'floor_area_degree')
    df_floor_degree                   = pd.DataFrame.from_dict(floor_area_degree, orient = 'columns')
    df1['floor_area_degree']          = df_floor_degree['floor_area_degree']

    housing_ratio_degree             = make_degree(df_house.values.tolist(), 'housing_ratio_degree')
    df_housing_ratio                 = pd.DataFrame.from_dict(housing_ratio_degree, orient = 'columns')
    df1['housing_ratio_degree']      = df_housing_ratio['housing_ratio_degree']

    cputime.tick('calculation accomplished')

## STEP 5 - write down table

    name = 'streetblock_index_Keelung'
    tab1  = mydb.get_alias(name)
    
    tab1.write(df1)
 
    cputime.tick('table has been writen down')

    

