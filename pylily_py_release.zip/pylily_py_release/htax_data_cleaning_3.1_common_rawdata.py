import csv
import pandas

def read_origin_htax_file():
    import ctao2_foreach 
    from Lily.ctao2.ctao2_database_mediator import manidb
    mydb        = manidb(r'g:\NCREE_GIS\TP_address\tp_address.sqlite')
    ftab        = mydb.get_alias('data_tp_housetax')
    mtab        = mydb.get_alias('data_tp_housetax_pattern_decomposition')

    # 開啟 CSV 檔案
    #csvfile = open(r'''g:\NCREE_GIS\TP_address\tp\HOUF43D''', 'r', encoding='utf-8') 
    #list1 = csvfile.readlines()
    #csvfile.close()

    #ftab.tick(f'read csv data')
    #table = []
    #for l in list1:
    #    line = l.split()
    #    table.append ([ line[0], line[1] ])
    #dataframe = pandas.DataFrame(table,columns=['taxid','ADDRESS'])

    dataframe = ftab.read()

    ftab.tick(f'todata frame')

    mtab.write(dataframe)
    
    ftab.tick(f'write out dataframe')

def collect_datatable():
    #cook script function

    from Lily.ctao2.ctao2_database_mediator import manidb
    #
    coll_list ={
#        r'g:/NCREE_GIS/confidential_nsg_common.sqlite' : ['data_bnd_3826_tract', 'data_bnd_3826_town'],
#        r'g:/NCREE_GIS/confidential_moi2013_numTaiwan.sqlite' : ['data_moi_raod', 'data_moi_town', 'data_moi_village']
    }

    omydb = manidb(r'g:/NCREE_GIS/tgbs_data_cleanning_2020/common.sqlite')

    for database_path in coll_list:
        mydb = manidb(database_path)
        for table in coll_list[database_path]:
            dataframe = mydb.get_alias(table).read()
            omydb.get_alias(table).write(dataframe)

def mitg_datatable():
    #cook script function
    from Lily.ctao2.ctao2_database_mediator import manidb
  
    mydb = manidb(r'g:/NCREE_GIS/tgbs_data_cleanning_2020/common.sqlite')
    road = mydb.get_alias('data_moi_road').read('roadid')
    road = road.drop(columns= ['id', 'roadtype', 'roadstruct', 'fnode', 'tnode', 'source', 'definition', 'mdate'])
    mydb.get_alias('data_moi_road_2').write(road)

def ismatch_pattern (val, repattern):
    if val == '':
        return  'none'

    match = re.match(repattern, val)

    if match:
        tg =  [ str(x or '') for x in match.groups() ]
        mtext =  ','.join( tg )
        return mtext 
    else:
        return 'irregular'

def DECOMPOSITION (val, PATTERN_DICT):
    import re
    
    rdset = {}
    if val == '':
            rdset['rep_level']          = 'none'
            rdset['decomposition']      = 'none'
    else:
        for rep_level, repatt in CT2_ADDR_PATTERN_DICT.items() :
            repattern       = re.compile(repatt)
            match           = re.match(repattern, val )

            if match:
                rdset['rep_level']          = rep_level
                rdset['decomposition']      = ','.join( [ str(x or '') for x in match.groups()] )
                break
            else:
                rdset['rep_level']          = 'irregular'
                rdset['decomposition']      = 'irregular'

    return (key, rdset)

if __name__ == '__console__' or __name__ == '__main__':
    import re
    from Lily.ctao2.ctao2_database_mediator import manidb
    
    mydb    = manidb(r'g:/NCREE_GIS/tgbs_data_cleanning_2020/common_nsg.sqlite')

    ftown   = mydb.get_alias('metaview_nsg_town_regular_expression')
    froadg  = mydb.get_alias('metaview_shand_moi_road_group')

    town    = ftown.read('cnty_name || town_name')
    roadg   = froadg.read('county || town')


    roadg ['town_code'] = 'none'

    for key , row in roadg.iterrows():
        if key in town.index:
            roadg.at[key, 'town_code'] = town.loc[key, 'town_code']
        else:
            for key2, repatt  in town.re.items():
                repattern       = re.compile(repatt)
                match           = re.match(repattern, key )
                if match:
                    roadg.at[key, 'town_code'] = town.loc[key2, 'town_code']
                    break

    #for debug
    mydb.get_alias('debug_nsg_road_town_code').write(roadg.sort_values(by=['county', 'town_code']))
    
    road                = mydb.get_alias('metadata_shand_moi_road').read()
    df                  = road.merge(roadg, on=['county', 'town'], how='left')

#    CT2_LANE1           = lambda x :  ismatch_pattern(x,  r'(?:([0-9０-９一二三四五六七八九十○]{1,4})巷)' )
      
    CT2_LANE1           = lambda x :  ismatch_pattern(x,  r'([0-9]{1,4})巷' )
    CT2_LANE2           = lambda x :  ismatch_pattern(x,  r'([\u4e00-\u9fa5]{1,4}巷)' )
    CT2_ALLEY           = lambda x :  ismatch_pattern(x,  r'([0-9]{1,4})弄' )

    df['H_road']        = ''

    df['roadname']      = df['roadname'].fillna('')
    df['rdnamenon']     = df['rdnamenon'].fillna('')
    df['rdnamesect']    = df['rdnamesect'].fillna('')
    df['rdnamelane']    = df['rdnamelane'].fillna('')

    df['H_road']        = df['roadname'] + df['rdnamesect']
    df['H_lane']        = df['rdnamelane'].apply(CT2_LANE1)
    df['C_lane']        = df['rdnamelane'].apply(CT2_LANE2)
    df['C_non']         = df['rdnamenon'] .apply(CT2_ALLEY)

    mydb.get_alias('debug_shand_moi_road').write(df.sort_values(by=['town_code']))