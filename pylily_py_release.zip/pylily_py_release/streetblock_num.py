import csv, xlrd
import numpy as np
import pandas as pd
from collections import Counter

from datetime import datetime
from Lily.ctao2.ctao2_database_alias import manidb, alias, tickwatch
from multiprocessing import Pool

def streetblock_count(arg):
    streetblock_id = pd.read_excel('G:/NCREE_GIS/Solution_Book/Project_C1_linxx_2020/streetblock_id.xlsx')
    list=[];    count_dict = {}
    list.append(streetblock_id)
    #print(list)
    count_dict = {}
    for item in arg:
        #print(item)
        if item in streetblock_id:
            count_dict[item] += 1
        else:
            count_dict[item] = 1

if __name__ == '__console__' or __name__ == '__main__':

    cputime = tickwatch()
    mydb = manidb('G:/NCREE_GIS/Solution_Book/Project_C1_linxx_2020/tp_address.sqlite')

    #resource
    tab0 = mydb.get_alias('data_sbldg_in_streetblock')
    tab00 = mydb.get_alias('data_nsg_streetblock_view_i')

    #outcome
    #read origin data
    tab1 = mydb.get_alias('data_calc_result')
    df2  = tab0.read()
    dfsb = tab00.read('nsg_key')

    #count number of group by nsg_key
    dfg  = df2.groupby(['streetblock_key'])


    calc_a = dfg.count() [['nsg_key']]
    calc_a = calc_a.rename (columns={'nsg_key':'num'})
    dfsb['num'] = calc_a['num']



    #count number (before 1999) of group by nsg_key
    df3 = df2[ df2['Constr_yr'] <= 1999 ]
    dfg = df3.groupby(['streetblock_key'])
    calc_b = dfg.count() [['nsg_key']]
    calc_a['b1999'] = calc_b['nsg_key']

    dfsb['b1999_ratio'] =  calc_a['b1999']/calc_a['num']

    #
    df2['BHR'] =  df2['BussArea'] / df2['FloorArea']
    df3 = df2[ df2['BHR'] <= 0.75]
    df3 = df3[ df3['BHR'] >= 0.25]
    dfg = df3.groupby(['streetblock_key'])
    calc_b = dfg.count() [['nsg_key']]
    calc_a['BH_MIX'] = calc_b['nsg_key']
    dfsb['BH_MIX_ratio'] =  calc_a['BH_MIX']/calc_a['num']
    
    # building_area
    dfg = df2.groupby(['streetblock_key'])
    calc_b = dfg.sum() [['FloorArea']]
    dfsb['FloorArea_sum'] = calc_b['FloorArea']

    #floorarea_landarea_ratio
    #dfsb =  dfsb [ dfsb['taipei'] == 1]
    dfsb['whole_blockarea'] = dfsb['daanpark_ind']
    dfsb['FLR'] =  dfsb['FloorArea_sum'] / dfsb['whole_blockarea']

    #population_dense
    dfsb['pop_dense'] =  dfsb['population_cnt'] / dfsb['whole_blockarea']
    dfsb.loc[ dfsb['pop_dense'] > 0.75, 'pop_dense_degree'] = 3
    dfsb.loc[ dfsb['pop_dense'] < 0.25, 'pop_dense_degree'] = 1

    tab1.write_with_index(dfsb)

    #cputime.tick()

    ##read Addr_key column
    #list1 = df2.streetblock_key.to_list()
    #mpool = Pool(8)
    #streetblock = read_excel()
    #print()
    #streetblock = mpool.map(read_excel, list1)
    #mpool.close()
    
    #cputime.tick()

    #df2 = pd.DataFrame.from_dict(streetblock_count , orient = 'columns')

    #cputime.tick('calculation accomplished')

    #tab1.write(df2)
 
    #cputime.tick('write down dataframe')

